// const fs = require('fs');
// const pickle = require('node-pickle');

// // Read the .pkl file
// const pklData = fs.readFileSync('Randomforestmodel.pkl');

// // Create a new Pickle object
// const unpickler = new pickle.Unpickler(pklData);

// // Load the Python object from the Pickle file
// const pythonObject = unpickler.load();

// // Now you can work with the loaded Python object
// console.log('Loaded Python object:', pythonObject);

// // You can use pythonObject as needed in your Node.js application

//
import { pklToJson } from 'pkl-to-json';
let pklPath ="Randomforestmodel.pkl"
let jsonPath ="data.json"

// const pklPath = path.resolve('Randomforestmodel.pkl')
// const jsonPath = path.resolve('./data.json')

// From pkl to json
pklToJson.convert(pklPath, jsonPath);

// From json to pkl
// 
